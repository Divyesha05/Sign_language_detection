// script.js

// This function is called when the document is fully loaded
document.addEventListener("DOMContentLoaded", function() {
    // Your JavaScript code goes here
    console.log("Document is ready!");

    // Example: Change the text of an element with id="demo"
    var demoElement = document.getElementById("demo");
    if (demoElement) {
        demoElement.textContent = "Hello, world!";
    }
});
